﻿(function () {
    "use strict";

    window.onload = function(){
    	var ns = Q.use("fish");
    	ns.game.load();
    };
})();
